import React from 'react'
import Mymemo from './Mymemo'

export default function Contact() {
  return (
    <div>
        <Mymemo />
    </div>
  )
}
