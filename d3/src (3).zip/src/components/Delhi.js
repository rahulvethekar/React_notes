import React from 'react'

export default function Delhi() {
  return (
    <div>Delhi</div>
  )
}
