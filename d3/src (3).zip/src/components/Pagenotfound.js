import React from 'react'

export default function Pagenotfound() {
  return (
    <div>Pagenotfound</div>
  )
}
