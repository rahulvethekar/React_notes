import React from 'react'
import Myeffect from './Myeffect'

export default function Home() {
  return (
    <div>
        <h2> Home Page</h2>
           <Myeffect />
    </div>
  )
}
